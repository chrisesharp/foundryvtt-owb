
/* -------------------------------------------- */
/*  Hotbar Macros                               */
/* -------------------------------------------- */

/**
 * Create a Macro from an Item drop.
 * Get an existing item macro if one exists, otherwise create a new one.
 * @param {Object} data     The dropped data
 * @param {number} slot     The hotbar slot to use
 * @returns {Promise}
 */
export async function createOWBMacro(data, slot) {
    if ( data.type !== "Item" ) return;
    if (!( "data" in data ) ) return ui.notifications.warn("You can only create macro buttons for owned Items");
    const item = data.data;
  
    // Create the macro command
    const command = `game.owb.rollItemMacro("${item.name}");`;
    let macro = game.macros.contents.find(m => (m.name === item.name) && (m.command === command));
    if ( !macro ) {
      macro = await Macro.create({
        name: item.name,
        type: "script",
        img: item.img,
        command: command,
        flags: {"owb.itemMacro": true}
      });
    }
    game.user.assignHotbarMacro(macro, slot);
    return false;
  }
  
  /* -------------------------------------------- */
  
  /**
   * Create a Macro from an Item drop.
   * Get an existing item macro if one exists, otherwise create a new one.
   * @param {string} itemName
   * @return {Promise}
   */
  export function rollItemMacro(itemName) {
    const speaker = ChatMessage.getSpeaker();
    let actor;
    if ( speaker.token ) actor = game.actors.tokens[speaker.token];
    if ( !actor ) actor = game.actors.get(speaker.actor);
  
    // Get matching items
    const items = actor ? actor.items.filter(i => i.name === itemName) : [];
    if ( items.length > 1 ) {
      ui.notifications.warn(`Your controlled Actor ${name} has more than one Item with name ${itemName}. The first matched item will be chosen.`);
    } else if ( items.length === 0 ) {
      return ui.notifications.warn(`Your controlled Actor does not have an item named ${itemName}`);
    }
    const item = items[0];
  
    // Trigger the item roll
    return item.roll();
  }
  