export const preloadHandlebarsTemplates = async function () {
    const templatePaths = [
        //Character Sheets
        'systems/owb/templates/actors/character-html.html',
        'systems/owb/templates/actors/monster-html.html',
        //Actor partials
        //Sheet tabs
        'systems/owb/templates/actors/partials/character-header.html',
        'systems/owb/templates/actors/partials/character-attributes-tab.html',
        'systems/owb/templates/actors/partials/character-abilities-tab.html',
        'systems/owb/templates/actors/partials/character-spells-tab.html',
        'systems/owb/templates/actors/partials/character-inventory-tab.html',
        'systems/owb/templates/actors/partials/character-notes-tab.html',

        'systems/owb/templates/actors/partials/monster-header.html',
        'systems/owb/templates/actors/partials/monster-attributes-tab.html'
    ];
    return loadTemplates(templatePaths);
};
