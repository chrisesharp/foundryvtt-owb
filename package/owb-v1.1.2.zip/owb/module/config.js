export const OWB = {
  scores: {
    str: "OWB.scores.str.long",
    int: "OWB.scores.int.long",
    dex: "OWB.scores.dex.long",
    wis: "OWB.scores.wis.long",
    con: "OWB.scores.con.long",
    cha: "OWB.scores.cha.long",
  },
  roll_type: {
    result: "=",
    above: "≥",
    below: "≤"
  },
  saves_short: {
    death: "OWB.saves.death.short",
    wand: "OWB.saves.wand.short",
    paralysis: "OWB.saves.paralysis.short",
    breath: "OWB.saves.breath.short",
    spell: "OWB.saves.spell.short",
  },
  saves_long: {
    death: "OWB.saves.death.long",
    wand: "OWB.saves.wand.long",
    paralysis: "OWB.saves.paralysis.long",
    breath: "OWB.saves.breath.long",
    spell: "OWB.saves.spell.long",
  },
  armor : {
    unarmored: "OWB.armor.unarmored",
    light: "OWB.armor.light",
    heavy: "OWB.armor.heavy",
    shield: "OWB.armor.shield",
  },
  colors: {
    green: "OWB.colors.green",
    red: "OWB.colors.red",
    yellow: "OWB.colors.yellow",
    purple: "OWB.colors.purple",
    blue: "OWB.colors.blue",
    orange: "OWB.colors.orange",
    white: "OWB.colors.white"
  },
  languages: [
    "Common",
    "Lawful",
    "Chaotic",
    "Neutral",
    "Bugbear",
    "Doppelgänger",
    "Dragon",
    "Dwarvish",
    "Elvish",
    "Gargoyle",
    "Gnoll",
    "Gnomish",
    "Goblin",
    "Halfling",
    "Harpy",
    "Hobgoblin",
    "Kobold",
    "Lizard Man",
    "Medusa",
    "Minotaur",
    "Ogre",
    "Orcish",
    "Pixie"
  ],
  tags: {
    melee: "OWB.items.Melee",
    missile: "OWB.items.Missile",
    slow: "OWB.items.Slow",
    twohanded: "OWB.items.TwoHanded",
    blunt: "OWB.items.Blunt",
    brace: "OWB.items.Brace",
    splash: "OWB.items.Splash",
    reload: "OWB.items.Reload",
    charge: "OWB.items.Charge",
  },
  tag_images: {
    melee: "/systems/owb/assets/melee.png",
    missile: "/systems/owb/assets/missile.png",
    slow: "/systems/owb/assets/slow.png",
    twohanded: "/systems/owb/assets/twohanded.png",
    blunt: "/systems/owb/assets/blunt.png",
    brace: "/systems/owb/assets/brace.png",
    splash: "/systems/owb/assets/splash.png",
    reload: "/systems/owb/assets/reload.png",
    charge: "/systems/owb/assets/charge.png",
  },
  monster_saves: {
    0: {
      label: "Normal Human",
      d: 14,
      w: 15,
      p: 16,
      b: 17,
      s: 18
    },
    1: {
      label: "1-3",
      d: 12,
      w: 13,
      p: 14,
      b: 15,
      s: 16
    },
    4: {
      label: "4-6",
      d: 10,
      w: 11,
      p: 12,
      b: 13,
      s: 14
    },
    7: {
      label: "7-9",
      d: 8,
      w: 9,
      p: 10,
      b: 10,
      s: 12
    },
    10: {
      label: "10-12",
      d: 6,
      w: 7,
      p: 8,
      b: 8,
      s: 10
    },
    13: {
      label: "13-15",
      d: 4,
      w: 5,
      p: 6,
      b: 5,
      s: 8
    },
    16: {
      label: "16-18",
      d: 2,
      w: 3,
      p: 4,
      b: 3,
      s: 6
    },
    19: {
      label: "19-21",
      d: 2,
      w: 2,
      p: 2,
      b: 2,
      s: 4
    },
    22: {
      label: "22+",
      d: 2,
      w: 2,
      p: 2,
      b: 2,
      s: 2
    },
  }
};